﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DiskUsage
{
   public class DiskProperties
    {
        public string FullName;
        public long FileLength;

        public string getfullname()
        {
            return FullName;
        }

        public void setfullname(string fullname)
        {
            this.FullName = fullname;
        }

        public long getfilelength()
        {
            return FileLength;
        }

        public void setfilelength(long filelength)
        {
            this.FileLength = filelength;
        }
    }
}
