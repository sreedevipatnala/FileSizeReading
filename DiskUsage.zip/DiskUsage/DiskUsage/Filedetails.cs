﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DiskUsage
{
    public class Filedetails
    {
        public List<DiskProperties> diskProperties;
        public List<DiskProperties> getfiles()
        {
            return diskProperties;
        }

        public void setfiles(List<DiskProperties> list)
        {
            this.diskProperties = list;
        }
    }
}
